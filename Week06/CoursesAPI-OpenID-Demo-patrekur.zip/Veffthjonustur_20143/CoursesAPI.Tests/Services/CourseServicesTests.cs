﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CoursesAPI.Tests.Services
{
	[TestClass]
	public class CourseServicesTests
	{
		[TestInitialize]
		public void Setup()
		{
			// TODO: code which will be executed before each test!
		}

		[TestMethod]
		public void TestMethod1()
		{
			// Arrange:

			// Act:

			// Assert:
		}
	}
}
